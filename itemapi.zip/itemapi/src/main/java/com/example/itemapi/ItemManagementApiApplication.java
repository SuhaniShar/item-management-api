package com.example.itemapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemManagementApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemManagementApiApplication.class, args);
	}

}
